
const animeData = [
  {
    title: "Attack on Titan",
    thumbnail: "https://via.placeholder.com/200x300?text=AOT",
    episodes: [
      { video: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { video: "https://www.w3schools.com/html/movie.mp4" }
    ]
  },
  {
    title: "Naruto",
    thumbnail: "https://via.placeholder.com/200x300?text=Naruto",
    episodes: [
      { video: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  }
];
